<script>import Table from './components/table.svelte';
import Footer from './components/footer.svelte';
import Header from './components/header.svelte';
export let name;
  import { onMount } from 'svelte';
  onMount(() => { 
    // runs after the dom elements were populated
    takeElementsHome();
  });

  function takeElementsHome(){
      const moveableElements = document.getElementsByClassName("moveable");
			for (let i=0; i < moveableElements.length; i++) {
        const current = moveableElements[i];

        // divs are having unique ids based on description name
        // label divs: 'description_name'$'tab_name'$label (e.g: Test$tab1$label)
        // container divs: 'description_name'$'tab_name'$container (e.g: Test$tab1$label)
        // since we need to move the content inside containers we add $container at the end
        const customTarget = document.getElementById(current.getAttribute("custom-target")+'$container');
        // only if specified element was found
				if(customTarget){
          // customTarget represents the new parent of the current element
          customTarget.appendChild(current);
        } 
      }
      // parsing again all moveable elements in order to
      // position the footer at the bottom of each custom container
      let i=0;
      while(i<moveableElements.length){
        const current = moveableElements[i];
        const parent = current.parentNode;
        let somethingRemoved = false;
        // if it's a footer then it appends at the bottom of the container
        if(current.id === 'footer'){
          somethingRemoved = removeDuplicateIDs(parent, 'footer');
        } else if(current.id ==='header'){
          somethingRemoved = removeDuplicateIDs(parent, 'header');
        }
        
        // incrementing index only if the dom wasn't modified
        if(!somethingRemoved){
          ++i;
        } else {
          // change was detected so it's safe to start from beginning
          i = 0;
        }
      }
    }

    function removeDuplicateIDs(parent, id){
      // variable used to know if something was removed
      let somethingRemoved = false;

      const parentChildNodes = parent.childNodes;
      let i=0;
      let unique;
      for(i; i<parentChildNodes.length;++i){
        if(parentChildNodes[i].id === id){
          // saving the unique element remaining after removal
          unique = parentChildNodes[i];
          break;
        }
      }
      // keeping one single item and removing other duplicates
      let j=i+1;
      while(j<parentChildNodes.length){
        if(parentChildNodes[j].id === id){
          parentChildNodes[j].remove();
          somethingRemoved = true;
        } else{
          j++;
        }
      }

      if(id ==='header'){
        // inserting header on the first position
        parent.insertBefore(unique, parentChildNodes[0]);
      } else {
        // id is footer so appending it to the end
        parent.insertBefore(unique, undefined);
        const offsetTop = unique.offsetTop;
        if(offsetTop < 200){
          // footer is not at the bottom
          unique.style.marginTop = "450px";
        } else if(offsetTop < 300){
          unique.style.marginTop = "350px";
        } else if(offsetTop < 400){
          unique.style.marginTop = "350px";
        } else if(offsetTop < 500){
          unique.style.marginTop = "150px";
        }
      }
      return somethingRemoved;
    }
</script>
<style>
</style>

<main><input type='hidden' value="f503c9e3-b20d-49e5-adb7-121141567909"/><Header/>
<Footer/>
<Table customData={{"url":"https://efpf.caixamagica.pt/efpftempapp/api/getAllSamples","path":"list_of_rows","preview":{"id":"7","timestamp":"2021-09-03 14:39:32.823","sensor":"efpftempsensor","temperature":"48"},"defaultSize":50}}/>
</main>