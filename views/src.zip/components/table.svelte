<script>
  import { onMount } from 'svelte';

  // variable used to store data coming from user input
  export let customData;

  let parent;
  onMount(() => {
      // runs after the dom elements were populated
      addCustomTarget();
  });
  // adds custom attribute to parent div
  function addCustomTarget() {
      if (customData && customData.customTarget) {
          // if it was selected anything else but not the default Append in page
          parent.setAttribute('custom-target', customData.customTarget);
      }
  }

  let loadingData = true


  let array = [];

  // used as sorting criteria
  let sortBy;

  let allData;
  let data = [];

  // used to display and iterate over data
  let columns = [];

  // flag used to know if user wanted select box or not
  let selectBoxVisible = false;

  // flag used to know if user wanted search box or not
  let searchBoxVisible = false;

  // variable binded to selectBox
  let selectedBoxOption;

  // keeps the customData.selectBox field which will separate the data
  let selectBoxField;

  // array with all options available in data
  let selectBoxOptions = [];

  // Stores the Search... input
  let searchValue;

  // dictionary used to separate data based on selectBoxOptions available
  let allDataDict = {};

  // used when no select box was added
  const defaultValue = "all";

  // Finding range for date pickers (from all Data)
  let minDateAll;
  let maxDateAll;

  // Containing the current selected date for both
  let currentDateFrom;
  let currentDateTo;

  // Finding range for date pickers (from all Data)
  let minCurrentDateTo;
  
  // used on datepickers data
  let datePickersField;

  // flag used to know when to display date pickers.
  let datePickersVisible = false;

  // binding dateTo date picker to this variable
  let dateToDatePicker;

  // binding dateTo date picker to this variable
  let dateFromDatePicker;

  // default size of the table
  const defaultNumberOfRows = 50;

  // variable used to keep track of the size of the table
  let defaultSize = defaultNumberOfRows;

  // variable taken from custom input
  let defaultCustomSize = defaultNumberOfRows;

  // flag used to know if it is a monitoring activities table or not
  let monitoringActivities = false;

  // variable used to keep the refresh time from modal dialog
  let refreshTime = 30;
 
  // variable used to know if there is more data in current table
  $: moreData = data.length > defaultSize;

  function extract_array(path, json) {
    let path_keys = path.split('.')

    let isArray = false;
    let array = [];
    for (var index in path_keys) {
      let key = path_keys[index];
      json = json[key];
      
      if (!json) {
        return false
      }

      if(Array.isArray(json))
      {  
        array = json;
        json = json[0];
        isArray = true;
      }
      else
      {
        isArray = false;
      }
      
    }
    if(isArray)
      return array;
    return false;
  }

  function getColumns(data) {
    // !IMPORTANT to update the headers on HTML
    columns = [];

    let sample;
    if (data.length > 0) {
       sample = data[0];
    }

    for (let key in sample) {
      // dropping selectBoxField from columns
      if(selectBoxField){ 
          if(selectBoxField === key){
              continue;
          }
      }
      columns.push(key);
    }

    // Holds table sort state.  Initialized to reflect table sorted by id column ascending.
    sortBy = { col: columns[0], ascending: false };
  }
  
  let sort = (column) => {
      if (sortBy.col === column) {
          sortBy.ascending = !sortBy.ascending;
      } else {
          sortBy.col = column;
          sortBy.ascending = true;
      }

      // Modifier to sorting function for ascending or descending
      let sortModifier = (sortBy.ascending) ? 1 : -1;
      let sort = (a, b) =>
          (a[column] < b[column])
              ? -1 * sortModifier
              : (a[column] > b[column])
                  ? 1 * sortModifier
                  : 0;
      // applying sort criteria
      data = data.sort(sort);
  };

  function getDataFromURL(url, path, previousSelectedOption) {
      console.log("Retrieving data from " + url)
      loadingData = true

      allData = [];
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function () {
          if (this.readyState == 4 && this.status == 200) {
              console.log("Data retrieved!");

              allData = JSON.parse(this.responseText);
              data = extract_array(path, allData)

              // only if select box was selected from modal dialog
              if(selectBoxVisible && selectBoxField){
                 // !IMPORTANT Otherwise the selectBox elements will not be populated
                 selectBoxOptions = [];
                 
                 splitDataIntoSmallArrays(selectBoxField, data);
                 selectBoxOptionChanged(previousSelectedOption);
              } else{
                selectedBoxOption = defaultValue;
                allDataDict[defaultValue] = data;
              }
              
              // getting columns and updating headers of table
              getColumns(data);

              // only when datePickers were wanted
              if(datePickersField){
                setMinMaxVaaluesOfData(data.slice());
              }

              loadingData = false;

          };
      }
      xhttp.open("GET", url, true);
      xhttp.send();
  }

  function splitDataIntoSmallArrays(selectBoxField, data){
      // parsing data and splitting into small arrays
      data.forEach(function(item){
        const current = item[selectBoxField];
        if(current){
          if(!selectBoxOptions.includes(current)){
            selectBoxOptions.push(current);

            // initializing empty array for each different selectBoxField
            allDataDict[current] = [];
          }
          
          // appending item to array
          allDataDict[current].push(item);
        }
      });

      // sorting ascending 
      selectBoxOptions.sort();
      selectedBoxOption = selectBoxOptions[0];
  }

  function selectBoxOptionChanged(option){
     // data was retrieved
     if(Object.keys(allDataDict).length > 0){
       
       if(typeof option ==='undefined'){
         option = selectedBoxOption;
       } else {
        selectedBoxOption = option;
       }

       data = allDataDict[option];

       // clearing searchBox's value
       if(searchBoxVisible){
          searchValue ="";
       }

       // clearing intervals
       // only when datepickers are visible
       if(datePickersField){
          setMinMaxValuesOfData(data.slice());
       }

       // resetting the default displayed size
       defaultSize = defaultCustomSize;
     }
     
  }

  function searchInData(e){
    // resetting the default displayed size
    defaultSize = defaultCustomSize;

    if(searchValue ==""){
      // refreshing data
      data = allDataDict[selectedBoxOption];
      return;
    }

    let new_array = [];
    // refreshing data
    data = allDataDict[selectedBoxOption];
    for (let j = 0; j < data.length; ++j) {
      for (let i = 0; i < columns.length; ++i){
          if(data[j][columns[i]]){
            // checking for null | undefined
            if (data[j][columns[i]].toString().indexOf(searchValue) > -1) {
              new_array.push(data[j]);
              // Only one match is needed
              break;
            }
          }
        }
      }
  
    if(new_array.length == 0){
      data = [createEmptyObject()];
    }else{
      // data was found
      data = new_array;
    }
  }
  
  function  createEmptyObject(){
    let emptyObject = {};
      columns.forEach(function(item){
        emptyObject[item] ="-";
      })
    return emptyObject;
  }

  function changeDateInterval(e) {
      // resetting the default value
      defaultSize = defaultCustomSize;

      // Finding the source of the change dateTo or dateFrom
      if (e.target.id === 'dateTo') {
        // Changing the current maxDate (entire day)
        currentDateTo = e.target.value;
      } else if (e.target.id === 'dateFrom') {
        // Changing the current min (start of the day)
        currentDateFrom = e.target.value;
      }
      minCurrentDateTo = currentDateFrom;
      if(currentDateFrom > currentDateTo)
         currentDateTo = currentDateFrom;
      filterByDate(currentDateFrom, currentDateTo);
      // Clearing any existent search strings
      searchValue = "";
  }


  function filterByDate(dateFrom, dateTo) {
     // refreshing data to search in all of it
     data = allDataDict[selectedBoxOption];
     let new_array = [];
     for (let j = 0; j < data.length; ++j) {
       if(data[j][datePickersField]){
        if ((data[j][datePickersField].substr(0,10) >= dateFrom) && (data[j][datePickersField].substr(0,10) <= dateTo))
          new_array.push(data[j]);
       }
     }

     if(new_array.length == 0){
        data = [createEmptyObject()];
     }else{
        data = new_array;
     }
  }

  function convertToExtendedFormat(value) {
      let string = '' + value;
      if (value < 10) string = '0' + string;
      return string;
  }


  function setMinMaxValuesOfData(array) {
      if (array && array.length > 0) {
        // Sorting the array data to find min and max values
        array.sort(function(a, b) {
          return (new Date(a[datePickersField]) - new Date(b[datePickersField]));
        });
        let min;
        let max;

        // finding the first non null value
        for(let i=0;i<array.length;++i){
          if(array[i][datePickersField]){
            // valid field (not null)
            const date = new Date(array[i][datePickersField]);

            // checking to see if it is a valid Date
            if(!isNaN(date)){
              min = date;
              break;
            }
          }
        }

        // finding the first non null value
        for(let i=array.length-1;i>=0;--i){
          if(array[i][datePickersField]){
            // valid field (not null)
            const date = new Date(array[i][datePickersField]);

            // checking to see if it is a valid Date
            if(!isNaN(date)){
              max = date;
              break;
            }
          }
        }

      // checking to see if selected field from modal it is in Date Format
      if(typeof max === 'undefined' || typeof min === 'undefined'){
          // wrong field chosen, not in a Date format
          // disabling date pickers
          dateToDatePicker.disabled = true;
          dateFromDatePicker.disabled = true;
          return;
      } else{
          // displaying for data when the selected field is in date format
          // enabling date pickers
          dateToDatePicker.disabled = false;
          dateFromDatePicker.disabled = false;
      }


        //Formating minDate and maxDate string to match input="date" requirements.
        const minDate =
          min.getFullYear() +
          '-' +
          // Adding 1 because months starts from 0
          convertToExtendedFormat(min.getMonth() + 1) +
          '-' +
          convertToExtendedFormat(min.getDate());
        const maxDate =
          max.getFullYear() +
          '-' +
          convertToExtendedFormat(max.getMonth() + 1) +
          '-' +
          convertToExtendedFormat(max.getDate());
  
        currentDateFrom = minDateAll = minCurrentDateTo = minDate;
        currentDateTo = maxDateAll = maxDate;
      }
  }
  
  function getCustomDataOptions(){
    if(customData){
      // custom data object was passed
      if(customData.selectBoxField){
        //selectBox was wanted
        selectBoxField = customData.selectBoxField;
        selectBoxVisible = true;
      }

      if(customData.searchBox){
        //searchBox was wanted
        searchBoxVisible = true;
      }

      if(customData.datePickersField){
        // date pickers were wanted
        datePickersField = customData.datePickersField;
        datePickersVisible = true;
       }

       if(customData.defaultSize){
         // changed default size of number of rows
         defaultCustomSize = customData.defaultSize;
         defaultSize = defaultCustomSize;
       }

       if(customData.monitoring){
          // monitoring application other features will be disabled
          monitoringActivities = true;
       }
       if(customData.refreshTime){
        // refresh time sent for monitoring activities
        refreshTime = customData.refreshTime;
       }
    }
  }

  function loadMoreDataInTable(){
    defaultSize += defaultNumberOfRows;
  }


  function initializeTable(){
    // getting every custom functionality passed by the modal dialog
    getCustomDataOptions();

    getDataFromURL(customData.url, customData.path); 
  }

  let counter = 1;
  // function that makes a GET to the specified URL at specific time interval
  // here it is 30 * 1000ms = 30000ms = 30 seconds
  setInterval(function(){
    if(monitoringActivities){
      if(counter == refreshTime){
        
        // making a copy to previous selected option before refresh
        const previousSelectedOption = selectedBoxOption;
        counter = 0;
        getDataFromURL(customData.url, previousSelectedOption);        
      } else{
        counter++;
      }      
    }
  }, 1000);
  
  initializeTable();

</script>

<style>
  table,
  th,
  tr,
  td {
      border: 1px solid black;
      border-collapse: collapse;
  }

  thead {
      display: table-header-group;
      vertical-align: middle;
      border-color: inherit;
  }

  tr {
      display: table-row;
      vertical-align: inherit;
      border-color: inherit;
  }

  td {
      display: table-cell;
      vertical-align: inherit;
  }

  table {
    width: 100%;
    text-align: center;
  }

  #data-visualization{
    vertical-align: top;
    margin: 20px;
  }
</style>
<section bind:this={parent} class="moveable">
<div id="data-visualization" style="text-align:center;">
  <!-- Select Box -->
    <!-- svelte-ignore a11y-no-onchange -->
    <!-- Showing select box based on user prefferences -->
    {#if selectBoxVisible}
          <select
            style="max-width: 200px; margin-right:1%;"
            bind:value={selectedBoxOption}
            on:change={() => {
              selectBoxOptionChanged(selectedBoxOption)}}>
            <optgroup label={selectBoxField}>
              {#each selectBoxOptions as selectOption}
                <option value={selectOption}>{selectOption}</option>
              {/each}
            </optgroup>
          </select>
      {/if}
    <!-- Search Box -->
    {#if searchBoxVisible}
      <input
        style="margin-right:1%;"
        on:keyup={e => searchInData(e)}
        placeholder="Search..."
        bind:value={searchValue} />
    {/if}
    {#if datePickersVisible}  
      <input
        bind:this={dateFromDatePicker}
        style="margin-right:2%;"
        type="date"
        id="dateFrom"
        title="Date From"
        value={currentDateFrom}
        min={minDateAll}
        max={maxDateAll}
        on:change={e => {
          changeDateInterval(e);
        }} />
      <input
        bind:this={dateToDatePicker}
        type="date"
        id="dateTo"
        title="Date To"
        min={minCurrentDateTo}
        max={maxDateAll}
        value={currentDateTo}
        on:change={e => {
          changeDateInterval(e);
        }} />
      {/if}

  <div style="width:100%; max-height:500px; overflow:auto;">
      <table>
          <thead>
              <tr>
                  {#each columns as col}
                    <th style="cursor:pointer;" on:click={() => sort(col)}>{col.charAt(0).toUpperCase() + col.slice(1)}&uarr;&darr;</th>
                  {/each}
              </tr>
        </thead>
        <tbody>
          {#each data.slice(0, defaultSize) as row}
            <tr>
              {#each columns as col}
                <td>{row[col] !== undefined ? row[col] : ''}</td>
              {/each}
            </tr>
          {/each}
        </tbody>
      </table>
      <!-- Only if there is more data and it is not in monitoring mode -->
      {#if moreData & !monitoringActivities}
        <button on:click={loadMoreDataInTable} style="width:100%;">Load more...</button>
      {/if}
    </div>
    {#if loadingData}
       <p style="text-align:center;">Loading ...</p>
    {/if}
  </div>
  
</section>
