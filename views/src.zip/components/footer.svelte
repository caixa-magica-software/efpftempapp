<script>
  import { onMount } from 'svelte';

  // variable used to store data coming from user input
  export let customData;

  let parent;
  onMount(() => { 
         parent.id = "footer";
         // runs after the dom elements were populated
         addCustomTarget();
    });
  // adds custom attribute to parent div
  function addCustomTarget(){
    if(customData && customData.customTarget){
      // if it was selected anything else but not the default Append in page
      parent.setAttribute('custom-target', customData.customTarget);
    }
  }
</script>
<style>  
   div.footer_container {
     width:100%;
     height:106px;
     background:#333;
     text-align: center;
     padding-top:10px;

     position: sticky;
     bottom: 0;
     left: 0;
     
   }

   div.footer_container img{
     width: 48px;
     opacity: 0.5;
     margin-top: 20px;
   }

    div.footer_container div.link_container, div.footer_container div.link_container a  {
      line-height:10px;
      color: #AAA;
      font-size: 10px;
    }

    div.footer_container div.link_container div.vs {
     display:inline-block;
     padding-left:5px;
     border-right:1px solid #FFF;
     margin-right:5px;
     height:10px;
   }
</style>
<section bind:this={parent} class="moveable">
  <div class="footer_container">
    <div class="link_container">
      European Factory Platform © 2021
      <div class="vs"></div>
      <a href="https://www.efpf.org/home" target="_blank">Home</a>
      <div class="vs"></div>
      <a href="https://www.efpf.org/federation" target="_blank">Federation</a>
      <div class="vs"></div>
      <a href="https://www.efpf.org/platform" target="_blank">Platform</a>
      <div class="vs"></div>
      <a href="https://www.efpf.org/offering" target="_blank">Offering</a>
      <div class="vs"></div>
      <a href="https://www.efpf.org/partners" target="_blank">Partners</a>
      <div class="vs"></div>
      <a href="https://www.efpf.org/eff" target="_blank">EFF</a>
      <div class="vs"></div>
      <a href="https://www.efpf.org/privacy-policy" target="_blank">Privacy Notice</a>
    </div>
    <img src="./logo_white_nolabel.png" alt="logo" />
  </div>
</section>