<script>
  import { onMount } from 'svelte';

  // variable used to store data coming from user input
  export let customData;

  let parent;
  onMount(() => { 
         parent.id = "header";
         // runs after the dom elements were populated
         addCustomTarget();
    });
  // adds custom attribute to parent div
  function addCustomTarget(){
    if(customData && customData.customTarget){
      // if it was selected anything else but not the default Append in page
      parent.setAttribute('custom-target', customData.customTarget);
    }
  }
</script>

<style>  
  .logo img{
    width: 100px;
    height: auto;
    vertical-align: top;
    position: absolute;
    margin-left: 4px;
    margin-top: 4px;
    left:0;
    top: 0;
    cursor: pointer;
    z-index: 9002;
  }

  .navbar-fixed-top {
    background:#FFF;
    height: 106px;
    border-bottom: 1px solid #DDD;
    z-index: 9001;

    position: absolute; /* Set the navbar to fixed position */
    top: 0; /* Position the navbar at the top of the page */
    width: 100%; /* Full width */
  }

</style>
<section bind:this={parent} class="moveable">
  <div class="navbar-fixed-top">
    <div class="logo">
      <img src="./header_logo.png" alt="European Factory Platform"/>
    </div>
  </div>
  <div style="margin-top:106px;"></div>
</section>